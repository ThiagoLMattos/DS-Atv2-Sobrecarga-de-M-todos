public class ConversorTemperatura {

    //usar static nas classes pra evitar erros com o Main.Java
    //FahrenheitScan para diferenciar metódos entre celsius e fahrenheit
    
    public static double conversor(double c) {
        return (c * (9.0/5.0)) + 32.0; //c -> f
    }

    public static double conversor(double f, boolean fahrenheitScan) { //diferenciar os metodos e aplicar sobrecarga
        return (f - 32.0) * (5.0/9.0); //f -> c
    }

    public static double conversor(double c, double ajuste, boolean arredondar) {
        double resultado = ((c * 9.0/5.0) + 32.0) + ajuste; //c -> f + ajuste
        if (arredondar) {
            resultado = Math.round(resultado); //arredondar
        }
        return resultado;
    }

    //extra
    public static double conversor(double f, double ajuste, boolean arredondar, boolean fahrenheitScan) { //fahrenheit scan pra diferenciar;
        double resultado = (f - 32.0) * (5.0/9.0) + ajuste; //f -> c + ajuste
        if (arredondar) {
            resultado = Math.round(resultado); //arredondar
        }
        return resultado;
    }

    public static double[] conversor(double[] temperaturas) {
        double[] resultado = new double[temperaturas.length]; //definir o tamanho do array resultado
        for (int i = 0; i < temperaturas.length; i++) {
            resultado[i] = conversor(temperaturas[i]); // utilizar outra função para definir os valores, e salvar no array resultado
        }
        return resultado;
    }

    public static double[] conversor(double[] temperaturas, boolean fahrenheitScan) {
        double[] resultado = new double[temperaturas.length]; //definir o tamanho do array resultado
        for (int i = 0; i < temperaturas.length; i++) {
            resultado[i] = conversor(temperaturas[i], true); // utilizar outra função para definir os valores, e salvar no array resultado
        }
        return resultado;
    }
}
