import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x;

        do {
            System.out.println("\nConversor de temperatura\n\n1- Celsius para Fahrenheit\n2- Fahrenheit para Celsius\n3- Celsius para Fahrenheit (Com ajuste e arredondamento)\n4- Fahrenheit para Celsius (Com ajuste e arredondamento)\n5- Converter um array de temperaturas (Celsius para Fahrenheit)\n6- Converter um array de temperaturas (Fahrenheits para Celsius)\n0- Sair");
            x = input.nextInt();

            switch(x){
                case 1:
                    System.out.println("Digite a temperatura em Celsius: ");
                    double c = input.nextDouble();
                    System.out.println(c + "°C em Fahrenheit: " + ConversorTemperatura.conversor(c));
                break;

                case 2: 
                    System.out.print("Digite a temperatura em Fahrenheit: ");
                    double f = input.nextDouble();
                    System.out.println(f + "°F em Celsius: " + ConversorTemperatura.conversor(f, true));
                break;

                case 3:
                    System.out.println("Digite a temperatura em Celsius: ");
                    double celsiusAjuste = input.nextDouble();
                    System.out.println("Digite o ajuste: ");
                    double ajusteC = input.nextDouble();
                    System.out.println("Deseja arredondar o valor? (True = Sim, False = Não)");
                    boolean arredondarC = input.nextBoolean();
                    System.out.println("Resultado: " + ConversorTemperatura.conversor(celsiusAjuste, ajusteC, arredondarC));
                break;

                case 4:
                    System.out.println("Digite a temperatura em Fahrenheit: ");
                    double fahrenheitAjuste = input.nextDouble();
                    System.out.println("Digite o ajuste: ");
                    double ajusteF = input.nextDouble();
                    System.out.println("Deseja arredondar o valor? (True = Sim, False = Não)");
                    boolean arredondarF = input.nextBoolean();
                    System.out.println("Resultado: " + ConversorTemperatura.conversor(fahrenheitAjuste, ajusteF, arredondarF, true));
                break;


                case 5:
                    System.out.print("Quantas temperaturas deseja converter? ");
                    int tamanhoC = input.nextInt();
                    double[] temperaturasC = new double[tamanhoC];
                    for (int i = 0; i < tamanhoC; i++) {
                        System.out.print("Digite a temperatura " + (i + 1) + ": ");
                        temperaturasC[i] = input.nextDouble();
                    }
                    double[] resultadosC = ConversorTemperatura.conversor(temperaturasC);
                    System.out.println("Temperaturas convertidas:");
                    for (double temp : resultadosC) {
                        System.out.println(temp);
                    }
                break;

                case 6:
                    System.out.print("Quantas temperaturas deseja converter? ");
                    int tamanhoF = input.nextInt();
                    double[] temperaturasF = new double[tamanhoF];
                    for (int i = 0; i < tamanhoF; i++) {
                        System.out.print("Digite a temperatura " + (i + 1) + ": ");
                        temperaturasF[i] = input.nextDouble();
                    }
                    double[] resultadosF = ConversorTemperatura.conversor(temperaturasF, true);
                    System.out.println("Temperaturas convertidas:");
                    for (double temp : resultadosF) {
                        System.out.println(temp);
                    }
                break;

                case 0:
                    System.out.println("Saindo...");
                break;

                default:
                    System.out.println("Opção Inválida");
            }
        } while (x!= 0);
         input.close();
    }
}